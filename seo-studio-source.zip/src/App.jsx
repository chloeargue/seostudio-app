import { useState } from "react";
import "./App.css";

const NAV = [
  { id: "dashboard", icon: "📊", label: "Dashboard" },
  { id: "content", icon: "✨", label: "Contenu auto" },
  { id: "calendar", icon: "📅", label: "Calendrier SEO" },
  { id: "tracking", icon: "📈", label: "Suivi mensuel" },
  { id: "audit", icon: "🔍", label: "Audit gratuit" },
];

const MONTHS = ["Jan","Fév","Mar","Avr","Mai","Jun","Jul","Aoû","Sep","Oct","Nov","Déc"];
const CURRENT_MONTH = 4;

const callClaude = async (prompt, apiKey) => {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, messages: [{ role: "user", content: prompt }] }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error?.message || `Erreur ${res.status}`);
  return data.content?.[0]?.text || "";
};

function EmptyState({ icon, message }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", height:320, gap:12, color:"#9ca3af" }}>
      <span style={{ fontSize:48 }}>{icon}</span>
      <p style={{ fontSize:14, textAlign:"center", maxWidth:280 }}>{message}</p>
    </div>
  );
}

function Spinner({ label }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", height:260, gap:14 }}>
      <div style={{ width:40, height:40, border:"3px solid #bbf7d0", borderTop:"3px solid #16a34a", borderRadius:"50%", animation:"spin 1s linear infinite" }} />
      <p style={{ fontSize:13, color:"#6b7280" }}>{label}</p>
    </div>
  );
}

function Btn({ onClick, disabled, color="#16a34a", children, small }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{ padding: small ? "6px 14px" : "9px 18px", borderRadius:8, border:"none", background: disabled ? "#9ca3af" : color, color:"#fff", fontWeight:600, fontSize: small ? 12 : 13, cursor: disabled ? "default" : "pointer" }}>
      {children}
    </button>
  );
}

/* ─────────── SETUP ─────────── */
function SetupScreen({ onComplete }) {
  const [form, setForm] = useState({ name:"", sector:"", location:"", website:"", audience:"" });
  const [errors, setErrors] = useState({});

  const update = (f, v) => setForm(p => ({ ...p, [f]: v }));
  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Requis";
    if (!form.sector.trim()) e.sector = "Requis";
    if (!form.location.trim()) e.location = "Requis";
    return e;
  };
  const submit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    onComplete(form);
  };
  const field = (id, label, ph, req) => (
    <div style={{ marginBottom:16 }}>
      <label style={{ display:"block", fontSize:13, fontWeight:600, color:"#374151", marginBottom:5 }}>{label}{req && <span style={{ color:"#dc2626", marginLeft:2 }}>*</span>}</label>
      <input value={form[id]} onChange={e => { update(id, e.target.value); setErrors(p => ({ ...p, [id]:undefined })); }} placeholder={ph}
        style={{ width:"100%", fontSize:13, padding:"9px 12px", borderRadius:8, border:`1px solid ${errors[id]?"#dc2626":"#d1d5db"}`, outline:"none", boxSizing:"border-box" }} />
      {errors[id] && <p style={{ fontSize:11, color:"#dc2626", marginTop:3 }}>{errors[id]}</p>}
    </div>
  );
  return (
    <div style={{ minHeight:"100vh", background:"#f9fafb", display:"flex", alignItems:"center", justifyContent:"center", padding:"2rem" }}>
      <div style={{ background:"#fff", borderRadius:16, border:"1px solid #e5e7eb", padding:"2.5rem", width:"100%", maxWidth:480, boxShadow:"0 4px 24px rgba(0,0,0,0.06)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:6 }}>
          <div style={{ width:36, height:36, borderRadius:10, background:"#16a34a", display:"flex", alignItems:"center", justifyContent:"center", fontSize:18 }}>📈</div>
          <span style={{ fontWeight:700, fontSize:18, color:"#111827" }}>SEO Studio</span>
        </div>
        <p style={{ fontSize:13, color:"#6b7280", marginBottom:"1.75rem" }}>Configurez votre espace de travail pour commencer.</p>
        <form onSubmit={submit}>
          {field("name","Nom de l'entreprise","Ex : Menuiserie Dupont",true)}
          {field("sector","Secteur d'activité","Ex : Menuiserie, Plomberie…",true)}
          {field("location","Localisation","Ex : Paris, Lyon, Bordeaux…",true)}
          {field("website","Site web","https://www.example.com",false)}
          {field("audience","Cible / audience","Ex : Particuliers, PME, Artisans…",false)}
          <button type="submit" style={{ width:"100%", padding:"11px", borderRadius:9, border:"none", background:"#16a34a", color:"#fff", fontWeight:700, fontSize:14, cursor:"pointer", marginTop:4 }}>
            Créer mon espace →
          </button>
        </form>
      </div>
    </div>
  );
}

/* ─────────── WORDPRESS MODAL ─────────── */
function WpModal({ result, keyword, onClose }) {
  const [wpUrl, setWpUrl] = useState("");
  const [wpUser, setWpUser] = useState("");
  const [wpPass, setWpPass] = useState("");
  const [publishing, setPublishing] = useState(false);
  const [status, setStatus] = useState(null);

  const extractTitle = (text) => {
    const line = text.split("\n").find(l => l.startsWith("# "));
    return line ? line.replace("# ", "").trim() : keyword || "Article SEO";
  };

  const mdToHtml = (text) => text.split("\n").map(line => {
    if (line.startsWith("## ")) return `<h2>${line.replace("## ","")}</h2>`;
    if (line.startsWith("# ")) return `<h1>${line.replace("# ","")}</h1>`;
    if (!line.trim()) return "<br>";
    return `<p>${line}</p>`;
  }).join("\n");

  const publish = async () => {
    if (!wpUrl.trim() || !wpUser.trim() || !wpPass.trim()) return;
    setPublishing(true);
    setStatus(null);
    const base = wpUrl.replace(/\/$/, "");
    const token = btoa(`${wpUser}:${wpPass}`);
    try {
      const res = await fetch(`${base}/wp-json/wp/v2/posts`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Basic ${token}`,
        },
        body: JSON.stringify({
          title: extractTitle(result),
          content: mdToHtml(result),
          status: "draft",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || `Erreur ${res.status}`);
      setStatus({ ok: true, link: data.link, editLink: `${base}/wp-admin/post.php?post=${data.id}&action=edit` });
    } catch (e) {
      setStatus({ ok: false, msg: e.message });
    } finally {
      setPublishing(false);
    }
  };

  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.45)", zIndex:1000, display:"flex", alignItems:"center", justifyContent:"center", padding:"1rem" }}>
      <div style={{ background:"#fff", borderRadius:16, padding:"1.75rem", width:"100%", maxWidth:440, boxShadow:"0 8px 40px rgba(0,0,0,0.18)" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
          <p style={{ fontSize:15, fontWeight:700, color:"#111827", margin:0 }}>🌐 Publier sur WordPress</p>
          <button onClick={onClose} style={{ background:"none", border:"none", fontSize:18, cursor:"pointer", color:"#9ca3af" }}>✕</button>
        </div>

        {!status ? (
          <>
            <p style={{ fontSize:12, color:"#6b7280", marginBottom:16 }}>Le contenu sera publié en <strong>brouillon</strong>. Utilisez un mot de passe d'application WordPress.</p>
            {[
              ["wpUrl", "URL du site WordPress", "https://monsite.com", wpUrl, setWpUrl, "text"],
              ["wpUser", "Nom d'utilisateur", "admin", wpUser, setWpUser, "text"],
              ["wpPass", "Mot de passe d'application", "xxxx xxxx xxxx xxxx", wpPass, setWpPass, "password"],
            ].map(([id, label, ph, val, setter, type]) => (
              <div key={id} style={{ marginBottom:12 }}>
                <label style={{ fontSize:11, fontWeight:600, color:"#374151", marginBottom:4, display:"block" }}>{label}</label>
                <input value={val} onChange={e => setter(e.target.value)} placeholder={ph} type={type}
                  style={{ width:"100%", fontSize:12, padding:"8px 10px", borderRadius:8, border:"1px solid #d1d5db", boxSizing:"border-box", fontFamily: type==="password" ? "monospace" : "inherit" }} />
              </div>
            ))}
            <p style={{ fontSize:11, color:"#9ca3af", marginBottom:16 }}>Générez un mot de passe d'application dans <em>WordPress → Profil → Mots de passe d'application</em>.</p>
            <div style={{ display:"flex", gap:8 }}>
              <button onClick={publish} disabled={publishing || !wpUrl || !wpUser || !wpPass}
                style={{ flex:1, padding:"9px", borderRadius:8, border:"none", background: publishing||!wpUrl||!wpUser||!wpPass ? "#9ca3af" : "#3b82f6", color:"#fff", fontWeight:600, fontSize:13, cursor: publishing||!wpUrl||!wpUser||!wpPass ? "default" : "pointer" }}>
                {publishing ? "⏳ Publication..." : "🚀 Publier en brouillon"}
              </button>
              <button onClick={onClose} style={{ padding:"9px 16px", borderRadius:8, border:"1px solid #e5e7eb", background:"#f9fafb", fontSize:13, cursor:"pointer" }}>Annuler</button>
            </div>
          </>
        ) : status.ok ? (
          <div style={{ textAlign:"center", padding:"1rem 0" }}>
            <div style={{ fontSize:40, marginBottom:10 }}>✅</div>
            <p style={{ fontSize:14, fontWeight:600, color:"#15803d", marginBottom:6 }}>Brouillon publié avec succès !</p>
            <a href={status.editLink} target="_blank" rel="noreferrer"
              style={{ display:"inline-block", marginTop:8, padding:"8px 18px", borderRadius:8, background:"#3b82f6", color:"#fff", fontSize:12, fontWeight:600, textDecoration:"none" }}>
              Ouvrir dans WP Admin →
            </a>
            <br />
            <button onClick={onClose} style={{ marginTop:10, fontSize:12, color:"#6b7280", background:"none", border:"none", cursor:"pointer", textDecoration:"underline" }}>Fermer</button>
          </div>
        ) : (
          <div style={{ background:"#fef2f2", border:"1px solid #fecaca", borderRadius:10, padding:"1rem", color:"#dc2626", fontSize:13, marginBottom:12 }}>
            ⚠️ {status.msg}
            <br />
            <button onClick={() => setStatus(null)} style={{ marginTop:8, fontSize:12, color:"#dc2626", background:"none", border:"1px solid #fecaca", borderRadius:6, padding:"4px 10px", cursor:"pointer" }}>Réessayer</button>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─────────── CONTENU AUTO ─────────── */
function ContentTab({ client }) {
  const [genType, setGenType] = useState("article");
  const [keyword, setKeyword] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [showWp, setShowWp] = useState(false);

  const prompts = {
    article: `Expert SEO français. Client: ${client.name} (${client.sector}, ${client.location})${client.audience ? `, audience: ${client.audience}` : ""}.\nMot-clé cible: "${keyword}".\nGénère un article complet:\n# [Titre H1 optimisé]\n\nMETA TITLE: [60 car max]\nMETA DESCRIPTION: [155 car max]\n\n## Introduction\n[2 phrases percutantes]\n\n## [H2 principal]\n[contenu 80 mots]\n\n## [H2 secondaire]\n[contenu 80 mots]\n\n## Conclusion\n[CTA clair]\n\nMOTS-CLÉS SECONDAIRES: [liste 5]\nBALISES HN SUGGÉRÉES: [liste H2/H3]`,
    meta: `Expert SEO français. Client: ${client.name} (${client.sector}).\nMot-clé: "${keyword}".\nGénère UNIQUEMENT:\nMETA TITLE (60 car): [titre]\nMETA DESCRIPTION (155 car): [desc]\nH1: [titre page]\nH1 ALTERNATIF: [variante]\nURL SLUG: [slug]\nBALISE TITLE: [title tag]\nMOTS-CLÉS LSI: [5 variantes sémantiques]`,
    keywords: `Expert SEO français. Client: ${client.name} (${client.sector}, ${client.location}).\nThème: "${keyword}".\nGénère:\nMOTS-CLÉS PRINCIPAUX: liste 6\nLONGUE TRAÎNE: liste 8 expressions\nQUESTIONS FAQ: liste 5 questions\nMOTS-CLÉS LOCAUX: liste 4`,
  };

  const generate = async () => {
    if (!keyword.trim()) return;
    setLoading(true); setResult(null); setError(null);
    try { setResult(await callClaude(prompts[genType], import.meta.env.VITE_ANTHROPIC_API_KEY)); }
    catch (e) { setError(e.message || "Erreur lors de la génération. Vérifiez votre clé API et réessayez."); }
    finally { setLoading(false); }
  };

  return (
    <>
      {showWp && <WpModal result={result} keyword={keyword} onClose={() => setShowWp(false)} />}
      <div style={{ display:"grid", gridTemplateColumns:"260px 1fr", gap:16, minHeight:500 }}>
        <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem", display:"flex", flexDirection:"column", gap:14 }}>
          <p style={{ fontSize:12, fontWeight:600, color:"#374151", margin:0 }}>Paramètres</p>
          <div>
            <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Type de contenu</label>
            <select value={genType} onChange={e => setGenType(e.target.value)} style={{ width:"100%", fontSize:12, padding:"7px 8px", borderRadius:8, border:"1px solid #d1d5db", background:"#fff" }}>
              <option value="article">Article de blog</option>
              <option value="meta">Balises méta + Hn</option>
              <option value="keywords">Recherche mots-clés</option>
            </select>
          </div>
          <div>
            <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Mot-clé cible</label>
            <input value={keyword} onChange={e => setKeyword(e.target.value)} onKeyDown={e => e.key==="Enter" && generate()}
              placeholder={`Ex : ${client.sector} ${client.location}`}
              style={{ width:"100%", fontSize:12, padding:"7px 8px", borderRadius:8, border:"1px solid #d1d5db", boxSizing:"border-box" }} />
          </div>
          <button onClick={generate} disabled={loading || !keyword.trim()}
            style={{ marginTop:"auto", width:"100%", padding:"10px", borderRadius:8, border:"none", background:loading||!keyword.trim()?"#9ca3af":"#16a34a", color:"#fff", fontWeight:600, fontSize:13, cursor:loading||!keyword.trim()?"default":"pointer" }}>
            {loading ? "⏳ Génération..." : "✨ Générer"}
          </button>
        </div>

        <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem", overflowY:"auto" }}>
          {!result && !loading && !error && <EmptyState icon="📄" message="Choisissez un type, entrez un mot-clé et cliquez sur Générer." />}
          {loading && <Spinner label="Génération en cours…" />}
          {error && <div style={{ background:"#fef2f2", border:"1px solid #fecaca", borderRadius:10, padding:"1rem", color:"#dc2626", fontSize:13 }}>⚠️ {error}</div>}
          {result && !loading && (
            <div>
              <div style={{ display:"flex", gap:8, justifyContent:"flex-end", marginBottom:12 }}>
                <button onClick={() => navigator.clipboard.writeText(result)} style={{ fontSize:11, color:"#6b7280", background:"#f9fafb", border:"1px solid #e5e7eb", borderRadius:6, padding:"4px 10px", cursor:"pointer" }}>📋 Copier tout</button>
                <button onClick={() => setShowWp(true)} style={{ fontSize:11, color:"#fff", background:"#3b82f6", border:"none", borderRadius:6, padding:"4px 12px", cursor:"pointer", fontWeight:600 }}>🌐 Publier sur WordPress</button>
              </div>
              <div style={{ fontSize:13, lineHeight:1.8, color:"#374151" }}>
                {result.split("\n").map((line, i) => {
                  if (line.startsWith("## ")) return <h3 key={i} style={{ fontSize:15, fontWeight:600, borderLeft:"3px solid #16a34a", paddingLeft:10, margin:"14px 0 6px" }}>{line.replace("## ","")}</h3>;
                  if (line.startsWith("# ")) return <h2 key={i} style={{ fontSize:18, fontWeight:700, margin:"0 0 10px" }}>{line.replace("# ","")}</h2>;
                  if (/^(META|BALISE|MOT|URL|H1|MOTS|LONGUE|QUESTIONS)/.test(line)) return <div key={i} style={{ background:"#f9fafb", borderRadius:6, padding:"6px 10px", marginBottom:5, fontSize:12, fontFamily:"monospace", border:"1px solid #e5e7eb" }}>{line}</div>;
                  if (!line.trim()) return <br key={i} />;
                  return <p key={i} style={{ margin:"0 0 6px" }}>{line}</p>;
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

/* ─────────── CALENDRIER SEO ─────────── */
const EMPTY_SEASON = { label:"", start:0, end:1, focus:"", color:"#16a34a", icon:"🌿" };

function CalendarTab() {
  const [seasons, setSeasons] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_SEASON);
  const [editId, setEditId] = useState(null);

  const upd = (f, v) => setForm(p => ({ ...p, [f]: v }));

  const activeSeason = seasons.find(s => CURRENT_MONTH >= s.start && CURRENT_MONTH <= s.end);

  const save = () => {
    if (!form.label.trim()) return;
    if (editId !== null) {
      setSeasons(p => p.map(s => s.id === editId ? { ...form, id: editId } : s));
      setEditId(null);
    } else {
      setSeasons(p => [...p, { ...form, id: Date.now() }]);
    }
    setForm(EMPTY_SEASON);
    setShowForm(false);
  };

  const startEdit = (s) => { setForm({ label:s.label, start:s.start, end:s.end, focus:s.focus, color:s.color, icon:s.icon }); setEditId(s.id); setShowForm(true); };
  const remove = (id) => setSeasons(p => p.filter(s => s.id !== id));

  const SeasonForm = () => (
    <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem", marginBottom:16 }}>
      <p style={{ fontSize:13, fontWeight:600, marginBottom:14 }}>{editId !== null ? "Modifier la période" : "Nouvelle période"}</p>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
        <div>
          <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Nom de la période</label>
          <input value={form.label} onChange={e => upd("label", e.target.value)} placeholder="Ex : Été, Hiver, Black Friday…"
            style={{ width:"100%", fontSize:12, padding:"7px 8px", borderRadius:8, border:"1px solid #d1d5db", boxSizing:"border-box" }} />
        </div>
        <div>
          <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Emoji icône</label>
          <input value={form.icon} onChange={e => upd("icon", e.target.value)} placeholder="🌿"
            style={{ width:"100%", fontSize:12, padding:"7px 8px", borderRadius:8, border:"1px solid #d1d5db", boxSizing:"border-box" }} />
        </div>
        <div>
          <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Mois de début</label>
          <select value={form.start} onChange={e => upd("start", +e.target.value)} style={{ width:"100%", fontSize:12, padding:"7px 8px", borderRadius:8, border:"1px solid #d1d5db" }}>
            {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
          </select>
        </div>
        <div>
          <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Mois de fin</label>
          <select value={form.end} onChange={e => upd("end", +e.target.value)} style={{ width:"100%", fontSize:12, padding:"7px 8px", borderRadius:8, border:"1px solid #d1d5db" }}>
            {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
          </select>
        </div>
        <div style={{ gridColumn:"1/-1" }}>
          <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Mots-clés focus (séparés par virgule)</label>
          <input value={form.focus} onChange={e => upd("focus", e.target.value)} placeholder="Ex : élagage arbre, taille haie, jardinage…"
            style={{ width:"100%", fontSize:12, padding:"7px 8px", borderRadius:8, border:"1px solid #d1d5db", boxSizing:"border-box" }} />
        </div>
        <div>
          <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Couleur</label>
          <input type="color" value={form.color} onChange={e => upd("color", e.target.value)}
            style={{ width:"100%", height:36, borderRadius:8, border:"1px solid #d1d5db", cursor:"pointer", padding:2 }} />
        </div>
      </div>
      <div style={{ display:"flex", gap:8 }}>
        <Btn onClick={save} small>{editId !== null ? "Enregistrer" : "Ajouter"}</Btn>
        <Btn onClick={() => { setShowForm(false); setEditId(null); setForm(EMPTY_SEASON); }} color="#6b7280" small>Annuler</Btn>
      </div>
    </div>
  );

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
        <p style={{ fontSize:13, color:"#6b7280" }}>Définissez vos périodes SEO saisonnières.</p>
        {!showForm && <Btn onClick={() => setShowForm(true)} small>+ Ajouter une période</Btn>}
      </div>

      {showForm && <SeasonForm />}

      <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem", marginBottom:16 }}>
        <p style={{ fontSize:13, fontWeight:600, marginBottom:14 }}>Calendrier annuel</p>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(12,1fr)", gap:4 }}>
          {MONTHS.map((m, i) => {
            const s = seasons.find(s => i >= s.start && i <= s.end);
            const isNow = i === CURRENT_MONTH;
            return (
              <div key={m} style={{ textAlign:"center" }}>
                <div style={{ height:36, borderRadius:7, background: s ? `${s.color}22` : "#f9fafb", border:`2px solid ${isNow ? "#16a34a" : s ? s.color : "#e5e7eb"}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:15, marginBottom:4, position:"relative" }}>
                  {s ? s.icon : ""}
                  {isNow && <span style={{ position:"absolute", top:-5, right:-3, width:8, height:8, background:"#16a34a", borderRadius:"50%", border:"1.5px solid #fff" }} />}
                </div>
                <span style={{ fontSize:9, color: isNow ? "#16a34a" : "#9ca3af", fontWeight: isNow ? 700 : 400 }}>{m}</span>
              </div>
            );
          })}
        </div>
        {activeSeason && (
          <div style={{ marginTop:12, padding:"8px 12px", background:"#f0fdf4", borderRadius:8, border:"1px solid #bbf7d0", fontSize:12, color:"#15803d" }}>
            <strong>Période active :</strong> {activeSeason.icon} {activeSeason.label} — Focus : {activeSeason.focus}
          </div>
        )}
      </div>

      {seasons.length === 0 && !showForm && <EmptyState icon="📅" message="Aucune période définie. Cliquez sur « Ajouter une période » pour commencer." />}

      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
        {seasons.map(s => (
          <div key={s.id} style={{ background:"#fff", borderRadius:12, border:`1px solid ${s.color}44`, padding:"1rem 1.25rem", display:"flex", alignItems:"center", gap:12 }}>
            <span style={{ fontSize:26, flexShrink:0 }}>{s.icon}</span>
            <div style={{ flex:1 }}>
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:3 }}>
                <span style={{ fontSize:13, fontWeight:600 }}>{s.label}</span>
                <span style={{ fontSize:11, background:`${s.color}22`, color:s.color, padding:"2px 8px", borderRadius:10, fontWeight:600 }}>{MONTHS[s.start]} → {MONTHS[s.end]}</span>
                {CURRENT_MONTH >= s.start && CURRENT_MONTH <= s.end && (
                  <span style={{ fontSize:11, background:"#dcfce7", color:"#15803d", padding:"2px 8px", borderRadius:10, fontWeight:600 }}>✓ Actif</span>
                )}
              </div>
              {s.focus && <p style={{ fontSize:12, color:"#6b7280", margin:0 }}>Focus : {s.focus}</p>}
            </div>
            <button onClick={() => startEdit(s)} style={{ fontSize:12, background:"#f9fafb", border:"1px solid #e5e7eb", borderRadius:6, padding:"5px 10px", cursor:"pointer" }}>✏️</button>
            <button onClick={() => remove(s.id)} style={{ fontSize:12, background:"#fef2f2", border:"1px solid #fecaca", borderRadius:6, padding:"5px 10px", cursor:"pointer" }}>🗑️</button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ─────────── SUIVI MENSUEL ─────────── */
const EMPTY_MONTH = { label:"", sessions:"", keywords:"", conversions:"", articles:"" };

function TrackingTab({ months, setMonths }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_MONTH);

  const upd = (f, v) => setForm(p => ({ ...p, [f]: v }));

  const save = () => {
    if (!form.label.trim()) return;
    setMonths(p => [...p, { ...form, id: Date.now(), sessions:+form.sessions||0, keywords:+form.keywords||0, conversions:+form.conversions||0, articles:+form.articles||0 }]);
    setForm(EMPTY_MONTH);
    setShowForm(false);
  };

  const pct = (cur, prev) => {
    if (!prev) return null;
    const diff = ((cur - prev) / prev) * 100;
    return diff;
  };
  const fmtPct = (v) => {
    if (v === null) return <span style={{ color:"#9ca3af" }}>—</span>;
    const color = v > 0 ? "#16a34a" : v < 0 ? "#dc2626" : "#6b7280";
    return <span style={{ color, fontWeight:600 }}>{v > 0 ? "+" : ""}{v.toFixed(1)}%</span>;
  };

  const thStyle = { fontSize:11, fontWeight:600, color:"#6b7280", padding:"8px 12px", textAlign:"left", background:"#f9fafb", borderBottom:"1px solid #e5e7eb" };
  const tdStyle = { fontSize:12, color:"#374151", padding:"10px 12px", borderBottom:"1px solid #f3f4f6" };

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
        <p style={{ fontSize:13, color:"#6b7280" }}>Suivez vos métriques SEO mois par mois.</p>
        {!showForm && <Btn onClick={() => setShowForm(true)} small>+ Ajouter un mois</Btn>}
      </div>

      {showForm && (
        <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem", marginBottom:16 }}>
          <p style={{ fontSize:13, fontWeight:600, marginBottom:14 }}>Nouveau mois</p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:12, marginBottom:12 }}>
            {[
              ["label","Mois","Ex : Janvier 2025"],
              ["sessions","Sessions","0"],
              ["keywords","Mots-clés top 10","0"],
              ["conversions","Conversions","0"],
              ["articles","Articles publiés","0"],
            ].map(([id, label, ph]) => (
              <div key={id}>
                <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>{label}</label>
                <input value={form[id]} onChange={e => upd(id, e.target.value)} placeholder={ph}
                  type={id === "label" ? "text" : "number"}
                  style={{ width:"100%", fontSize:12, padding:"7px 8px", borderRadius:8, border:"1px solid #d1d5db", boxSizing:"border-box" }} />
              </div>
            ))}
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <Btn onClick={save} small>Ajouter</Btn>
            <Btn onClick={() => { setShowForm(false); setForm(EMPTY_MONTH); }} color="#6b7280" small>Annuler</Btn>
          </div>
        </div>
      )}

      {months.length === 0 && !showForm && <EmptyState icon="📈" message="Aucune donnée. Cliquez sur « Ajouter un mois » pour commencer le suivi." />}

      {months.length > 0 && (
        <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", overflow:"hidden" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>
                {["Mois","Sessions","Évol.","Mots-clés top 10","Évol.","Conversions","Évol.","Articles publiés",""].map((h, i) => (
                  <th key={i} style={thStyle}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {months.map((m, i) => {
                const prev = months[i - 1];
                return (
                  <tr key={m.id} style={{ background: i % 2 === 0 ? "#fff" : "#fafafa" }}>
                    <td style={{ ...tdStyle, fontWeight:600, color:"#111827" }}>{m.label}</td>
                    <td style={tdStyle}>{m.sessions.toLocaleString()}</td>
                    <td style={tdStyle}>{fmtPct(pct(m.sessions, prev?.sessions))}</td>
                    <td style={tdStyle}>{m.keywords}</td>
                    <td style={tdStyle}>{fmtPct(pct(m.keywords, prev?.keywords))}</td>
                    <td style={tdStyle}>{m.conversions}</td>
                    <td style={tdStyle}>{fmtPct(pct(m.conversions, prev?.conversions))}</td>
                    <td style={tdStyle}>{m.articles}</td>
                    <td style={tdStyle}>
                      <button onClick={() => setMonths(p => p.filter(x => x.id !== m.id))} style={{ fontSize:11, color:"#dc2626", background:"#fef2f2", border:"1px solid #fecaca", borderRadius:6, padding:"3px 8px", cursor:"pointer" }}>✕</button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

/* ─────────── AUDIT ─────────── */
function ScoreBar({ label, score }) {
  const color = score >= 70 ? "#16a34a" : score >= 50 ? "#d97706" : "#dc2626";
  return (
    <div style={{ marginBottom:10 }}>
      <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
        <span style={{ fontSize:12, color:"#374151" }}>{label}</span>
        <span style={{ fontSize:12, fontWeight:700, color }}>{score}/100</span>
      </div>
      <div style={{ height:6, background:"#f3f4f6", borderRadius:4, overflow:"hidden" }}>
        <div style={{ height:"100%", width:`${score}%`, background:color, borderRadius:4 }} />
      </div>
    </div>
  );
}

function AuditTab({ client }) {
  const [url, setUrl] = useState(client.website || "");
  const [sector, setSector] = useState(client.sector || "");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const scoreColor = (s) => s >= 70 ? "#16a34a" : s >= 50 ? "#d97706" : "#dc2626";
  const scoreLabel = (s) => s >= 70 ? "Bon" : s >= 50 ? "À améliorer" : "Critique";
  const impactColor = (i) => i === "Fort" ? "#dc2626" : i === "Moyen" ? "#d97706" : "#6b7280";

  const runAudit = async () => {
    if (!url.trim()) return;
    setLoading(true); setResult(null); setError(null);
    const prompt = `Tu es un expert SEO. Génère un audit SEO réaliste pour "${url}" secteur "${sector||"non précisé"}". Réponds UNIQUEMENT en JSON valide sans backticks:\n{"score_global":72,"scores":{"technique":68,"contenu":75,"mots_cles":60,"mobile":85,"vitesse":70,"local":65},"points_forts":["Point 1","Point 2","Point 3"],"problemes":[{"titre":"Problème 1","impact":"Fort","action":"Action corrective"},{"titre":"Problème 2","impact":"Moyen","action":"Action corrective"},{"titre":"Problème 3","impact":"Faible","action":"Action corrective"}],"opportunites":["Opportunité 1","Opportunité 2","Opportunité 3"],"verdict":"Verdict en 2 phrases."}`;
    try {
      const text = await callClaude(prompt, client.apiKey);
      setResult(JSON.parse(text.trim()));
    } catch (e) {
      setError(e.message || "Impossible de générer l'audit. Vérifiez l'URL et réessayez.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth:780 }}>
      <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem", marginBottom:16 }}>
        <p style={{ fontSize:13, fontWeight:600, color:"#111827", marginBottom:14 }}>Analyser un site</p>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
          <div>
            <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>URL du site <span style={{ color:"#dc2626" }}>*</span></label>
            <input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://www.exemple.com"
              style={{ width:"100%", fontSize:13, padding:"8px 10px", borderRadius:8, border:"1px solid #d1d5db", boxSizing:"border-box" }} />
          </div>
          <div>
            <label style={{ fontSize:11, color:"#6b7280", marginBottom:4, display:"block" }}>Secteur d'activité</label>
            <input value={sector} onChange={e => setSector(e.target.value)} placeholder="Ex : Plomberie, E-commerce…"
              style={{ width:"100%", fontSize:13, padding:"8px 10px", borderRadius:8, border:"1px solid #d1d5db", boxSizing:"border-box" }} />
          </div>
        </div>
        <button onClick={runAudit} disabled={loading || !url.trim()}
          style={{ padding:"9px 20px", borderRadius:8, border:"none", background:loading||!url.trim()?"#9ca3af":"#16a34a", color:"#fff", fontWeight:600, fontSize:13, cursor:loading||!url.trim()?"default":"pointer" }}>
          {loading ? "⏳ Analyse en cours..." : "🔍 Lancer l'audit"}
        </button>
      </div>

      {loading && <Spinner label="Génération de l'audit SEO…" />}
      {error && <div style={{ background:"#fef2f2", border:"1px solid #fecaca", borderRadius:10, padding:"1rem", color:"#dc2626", fontSize:13 }}>⚠️ {error}</div>}

      {result && !loading && (
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem", display:"flex", alignItems:"center", gap:20 }}>
            <div style={{ width:80, height:80, borderRadius:"50%", border:`5px solid ${scoreColor(result.score_global)}`, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
              <span style={{ fontSize:26, fontWeight:700, color:scoreColor(result.score_global), lineHeight:1 }}>{result.score_global}</span>
              <span style={{ fontSize:10, color:"#9ca3af" }}>/100</span>
            </div>
            <div style={{ flex:1 }}>
              <p style={{ fontSize:14, fontWeight:700, color:"#111827", marginBottom:4 }}>Score global — <span style={{ color:scoreColor(result.score_global) }}>{scoreLabel(result.score_global)}</span></p>
              <p style={{ fontSize:12, color:"#6b7280", margin:0 }}>{result.verdict}</p>
            </div>
          </div>
          <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem" }}>
            <p style={{ fontSize:13, fontWeight:600, marginBottom:14 }}>Scores détaillés</p>
            {Object.entries(result.scores || {}).map(([k, v]) => (
              <ScoreBar key={k} label={{ technique:"Technique", contenu:"Contenu", mots_cles:"Mots-clés", mobile:"Mobile", vitesse:"Vitesse", local:"SEO Local" }[k]||k} score={v} />
            ))}
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:14 }}>
            <div style={{ background:"#f0fdf4", borderRadius:12, border:"1px solid #bbf7d0", padding:"1.25rem" }}>
              <p style={{ fontSize:13, fontWeight:600, color:"#15803d", marginBottom:10 }}>✅ Points forts</p>
              {(result.points_forts||[]).map((p, i) => <div key={i} style={{ fontSize:12, color:"#374151", padding:"5px 0", borderBottom: i<result.points_forts.length-1?"1px solid #bbf7d0":"none" }}>• {p}</div>)}
            </div>
            <div style={{ background:"#fff7ed", borderRadius:12, border:"1px solid #fed7aa", padding:"1.25rem" }}>
              <p style={{ fontSize:13, fontWeight:600, color:"#c2410c", marginBottom:10 }}>💡 Opportunités</p>
              {(result.opportunites||[]).map((o, i) => <div key={i} style={{ fontSize:12, color:"#374151", padding:"5px 0", borderBottom: i<result.opportunites.length-1?"1px solid #fed7aa":"none" }}>• {o}</div>)}
            </div>
          </div>
          <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem" }}>
            <p style={{ fontSize:13, fontWeight:600, marginBottom:12 }}>🔧 Problèmes à corriger</p>
            <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
              {(result.problemes||[]).map((p, i) => (
                <div key={i} style={{ padding:"10px 12px", borderRadius:8, background:"#f9fafb", border:"1px solid #e5e7eb", display:"flex", gap:12, alignItems:"flex-start" }}>
                  <span style={{ fontSize:11, fontWeight:700, color:impactColor(p.impact), background:`${impactColor(p.impact)}18`, padding:"2px 8px", borderRadius:10, flexShrink:0, marginTop:2 }}>{p.impact}</span>
                  <div>
                    <p style={{ fontSize:12, fontWeight:600, color:"#111827", margin:"0 0 3px" }}>{p.titre}</p>
                    <p style={{ fontSize:11, color:"#6b7280", margin:0 }}>→ {p.action}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ─────────── PDF REPORT ─────────── */
const generatePdf = (months, client) => {
  const last = months[months.length - 1];
  const prev = months[months.length - 2];
  const d = (cur, p) => (!p ? null : (((cur - p) / p) * 100).toFixed(1));
  const arrow = (v) => v === null ? "" : v > 0 ? `▲ +${v}%` : v < 0 ? `▼ ${v}%` : `→ 0%`;
  const maxS = Math.max(...months.map(m => m.sessions), 1);
  const barW = (v) => Math.max(Math.round((v / maxS) * 300), 4);

  const rows = months.map((m, i) => {
    const p = months[i - 1];
    return `<tr>
      <td>${m.label}</td>
      <td>${m.sessions.toLocaleString()}</td>
      <td style="color:${d(m.sessions,p?.sessions)>0?'#16a34a':d(m.sessions,p?.sessions)<0?'#dc2626':'#6b7280'}">${arrow(d(m.sessions,p?.sessions))}</td>
      <td>${m.keywords}</td>
      <td>${m.conversions}</td>
      <td>${m.articles}</td>
    </tr>`;
  }).join("");

  const bars = months.map(m =>
    `<div style="display:flex;align-items:center;gap:8px;margin-bottom:5px">
      <span style="width:60px;font-size:11px;color:#6b7280;text-align:right">${m.label}</span>
      <div style="height:18px;width:${barW(m.sessions)}px;background:#16a34a;border-radius:3px"></div>
      <span style="font-size:11px;color:#374151">${m.sessions.toLocaleString()}</span>
    </div>`
  ).join("");

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
  <title>Rapport SEO — ${client.name}</title>
  <style>
    body{font-family:system-ui,sans-serif;padding:40px;color:#111827;max-width:800px;margin:0 auto}
    h1{font-size:22px;margin:0 0 4px}
    .sub{font-size:13px;color:#6b7280;margin-bottom:32px}
    h2{font-size:15px;font-weight:700;margin:28px 0 12px;padding-bottom:6px;border-bottom:2px solid #e5e7eb}
    .kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:8px}
    .kpi{border:1px solid #e5e7eb;border-radius:10px;padding:12px}
    .kpi-label{font-size:11px;color:#6b7280;margin:0 0 4px}
    .kpi-val{font-size:26px;font-weight:700;margin:0 0 3px}
    .kpi-ev{font-size:11px;font-weight:600;margin:0}
    table{width:100%;border-collapse:collapse;font-size:12px}
    th{text-align:left;background:#f9fafb;padding:8px 10px;border-bottom:2px solid #e5e7eb;font-size:11px;color:#6b7280}
    td{padding:8px 10px;border-bottom:1px solid #f3f4f6}
    tr:nth-child(even){background:#fafafa}
    .footer{margin-top:40px;font-size:11px;color:#9ca3af;text-align:center}
    @media print{body{padding:20px}}
  </style></head><body>
  <h1>Rapport SEO — ${client.name}</h1>
  <p class="sub">${client.sector} · ${client.location}${client.website ? ` · ${client.website}` : ""} · Généré le ${new Date().toLocaleDateString("fr-FR", {day:"numeric",month:"long",year:"numeric"})}</p>

  <h2>KPIs — Dernier mois (${last.label})</h2>
  <div class="kpis">
    <div class="kpi"><p class="kpi-label">Sessions</p><p class="kpi-val" style="color:#2563eb">${last.sessions.toLocaleString()}</p><p class="kpi-ev" style="color:${d(last.sessions,prev?.sessions)>0?'#16a34a':'#dc2626'}">${arrow(d(last.sessions,prev?.sessions))}</p></div>
    <div class="kpi"><p class="kpi-label">Mots-clés top 10</p><p class="kpi-val" style="color:#16a34a">${last.keywords}</p><p class="kpi-ev" style="color:${d(last.keywords,prev?.keywords)>0?'#16a34a':'#dc2626'}">${arrow(d(last.keywords,prev?.keywords))}</p></div>
    <div class="kpi"><p class="kpi-label">Conversions</p><p class="kpi-val" style="color:#d97706">${last.conversions}</p><p class="kpi-ev" style="color:${d(last.conversions,prev?.conversions)>0?'#16a34a':'#dc2626'}">${arrow(d(last.conversions,prev?.conversions))}</p></div>
    <div class="kpi"><p class="kpi-label">Articles publiés</p><p class="kpi-val" style="color:#7c3aed">${last.articles}</p><p class="kpi-ev" style="color:${d(last.articles,prev?.articles)>0?'#16a34a':'#dc2626'}">${arrow(d(last.articles,prev?.articles))}</p></div>
  </div>

  <h2>Sessions par mois</h2>
  ${bars}

  <h2>Tableau complet</h2>
  <table>
    <thead><tr><th>Mois</th><th>Sessions</th><th>Évol.</th><th>Mots-clés top 10</th><th>Conversions</th><th>Articles</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>

  <p class="footer">SEO Studio · Rapport automatique · ${client.name}</p>
  <script>window.onload=()=>{window.print()}<\/script>
  </body></html>`;

  const w = window.open("", "_blank");
  w.document.write(html);
  w.document.close();
};

/* ─────────── DASHBOARD ─────────── */
const diffPct = (cur, prev) => (!prev ? null : ((cur - prev) / prev) * 100);

function KpiCard({ label, value, prevValue, color, icon }) {
  const diff = diffPct(value, prevValue);
  return (
    <div style={{ background:"#fff", borderRadius:12, padding:"1.1rem 1.25rem", border:"1px solid #e5e7eb" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
        <p style={{ fontSize:11, color:"#6b7280", margin:0 }}>{label}</p>
        <span style={{ fontSize:18 }}>{icon}</span>
      </div>
      <p style={{ fontSize:28, fontWeight:700, color, margin:"0 0 4px", lineHeight:1 }}>
        {typeof value === "number" ? value.toLocaleString() : value}
      </p>
      {diff !== null ? (
        <p style={{ fontSize:11, color: diff > 0 ? "#16a34a" : diff < 0 ? "#dc2626" : "#6b7280", margin:0, fontWeight:600 }}>
          {diff > 0 ? "▲" : diff < 0 ? "▼" : "→"} {Math.abs(diff).toFixed(1)}% vs mois précédent
        </p>
      ) : (
        <p style={{ fontSize:11, color:"#9ca3af", margin:0 }}>Premier mois enregistré</p>
      )}
    </div>
  );
}

function DashboardTab({ months, client }) {
  if (months.length === 0) {
    return (
      <div>
        <EmptyState icon="📊" message="Votre tableau de bord est vide. Ajoutez des données dans « Suivi mensuel » pour voir vos KPIs ici." />
        <div style={{ textAlign:"center", marginTop:4 }}>
          <span style={{ fontSize:12, color:"#9ca3af" }}>Les données apparaîtront automatiquement dès qu'un mois est ajouté.</span>
        </div>
      </div>
    );
  }

  const last = months[months.length - 1];
  const prev = months[months.length - 2] || null;
  const maxSessions = Math.max(...months.map(m => m.sessions), 1);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:20 }}>

      {/* Header row */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <p style={{ fontSize:13, color:"#6b7280", margin:0 }}>Données du mois le plus récent : <strong style={{ color:"#111827" }}>{last.label}</strong></p>
        <button onClick={() => generatePdf(months, client)} style={{ fontSize:12, color:"#fff", background:"#111827", border:"none", borderRadius:8, padding:"8px 16px", cursor:"pointer", fontWeight:600 }}>
          📄 Générer un rapport PDF
        </button>
      </div>

      {/* KPI cards */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12 }}>
        <KpiCard label="Sessions" value={last.sessions} prevValue={prev?.sessions} color="#2563eb" icon="👥" />
        <KpiCard label="Mots-clés top 10" value={last.keywords} prevValue={prev?.keywords} color="#16a34a" icon="🔑" />
        <KpiCard label="Conversions" value={last.conversions} prevValue={prev?.conversions} color="#d97706" icon="🎯" />
        <KpiCard label="Articles publiés" value={last.articles} prevValue={prev?.articles} color="#7c3aed" icon="📝" />
      </div>

      {/* Bar chart */}
      <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
          <p style={{ fontSize:13, fontWeight:600, color:"#111827", margin:0 }}>Sessions par mois</p>
          <span style={{ fontSize:11, color:"#9ca3af" }}>{months.length} mois enregistré{months.length > 1 ? "s" : ""}</span>
        </div>
        <div style={{ display:"flex", alignItems:"flex-end", gap:8, height:140 }}>
          {months.map((m, i) => {
            const isLast = i === months.length - 1;
            const barH = Math.max((m.sessions / maxSessions) * 120, 4);
            const prevM = months[i - 1];
            const diff = pct(m.sessions, prevM?.sessions);
            return (
              <div key={m.id} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:4, minWidth:0 }}>
                {diff !== null && (
                  <span style={{ fontSize:9, fontWeight:600, color: diff > 0 ? "#16a34a" : diff < 0 ? "#dc2626" : "#9ca3af", whiteSpace:"nowrap" }}>
                    {diff > 0 ? "+" : ""}{diff.toFixed(0)}%
                  </span>
                )}
                {diff === null && <span style={{ fontSize:9, color:"transparent" }}>–</span>}
                <div title={`${m.label} : ${m.sessions.toLocaleString()} sessions`}
                  style={{ width:"100%", background: isLast ? "#16a34a" : "#bbf7d0", borderRadius:"4px 4px 0 0", height:`${barH}px`, cursor:"default", transition:"height 0.3s ease" }} />
                <span style={{ fontSize:9, color: isLast ? "#15803d" : "#9ca3af", fontWeight: isLast ? 700 : 400, textAlign:"center", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap", maxWidth:"100%" }}>
                  {m.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent months summary */}
      {months.length > 1 && (
        <div style={{ background:"#fff", borderRadius:12, border:"1px solid #e5e7eb", padding:"1.25rem" }}>
          <p style={{ fontSize:13, fontWeight:600, color:"#111827", marginBottom:14 }}>Récapitulatif — 3 derniers mois</p>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit, minmax(160px, 1fr))", gap:12 }}>
            {months.slice(-3).map((m, i, arr) => {
              const p = arr[i - 1] || months[months.length - arr.length - 1 + i - 1] || null;
              const sessD = pct(m.sessions, months[months.indexOf(m) - 1]?.sessions);
              return (
                <div key={m.id} style={{ padding:"10px 12px", borderRadius:9, background:"#f9fafb", border:"1px solid #f3f4f6" }}>
                  <p style={{ fontSize:12, fontWeight:700, color:"#111827", margin:"0 0 8px" }}>{m.label}</p>
                  <p style={{ fontSize:11, color:"#6b7280", margin:"0 0 2px" }}>Sessions : <strong style={{ color:"#111827" }}>{m.sessions.toLocaleString()}</strong></p>
                  <p style={{ fontSize:11, color:"#6b7280", margin:"0 0 2px" }}>Mots-clés top 10 : <strong style={{ color:"#111827" }}>{m.keywords}</strong></p>
                  <p style={{ fontSize:11, color:"#6b7280", margin:"0 0 2px" }}>Conversions : <strong style={{ color:"#111827" }}>{m.conversions}</strong></p>
                  <p style={{ fontSize:11, color:"#6b7280", margin:0 }}>Articles : <strong style={{ color:"#111827" }}>{m.articles}</strong></p>
                  {sessD !== null && (
                    <p style={{ fontSize:11, fontWeight:600, color: sessD > 0 ? "#16a34a" : sessD < 0 ? "#dc2626" : "#6b7280", marginTop:6 }}>
                      Sessions {sessD > 0 ? "+" : ""}{sessD.toFixed(1)}% vs mois préc.
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
}

/* ─────────── APP SHELL ─────────── */
export default function App() {
  const [client, setClient] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [months, setMonths] = useState([]);

  if (!client) return <SetupScreen onComplete={(data) => setClient(data)} />;

  return (
    <div style={{ display:"flex", height:"100vh", fontFamily:"system-ui, -apple-system, sans-serif", background:"#f9fafb" }}>
      <div style={{ width:200, background:"#fff", borderRight:"1px solid #e5e7eb", padding:"1.25rem 1rem", display:"flex", flexDirection:"column", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:"0.5rem" }}>
          <div style={{ width:28, height:28, borderRadius:8, background:"#16a34a", display:"flex", alignItems:"center", justifyContent:"center", fontSize:14 }}>📈</div>
          <span style={{ fontWeight:700, fontSize:14, color:"#111827" }}>SEO Studio</span>
        </div>
        <p style={{ fontSize:11, color:"#9ca3af", marginBottom:"1.5rem" }}>{client.name}</p>
        {NAV.map(({ id, icon, label }) => (
          <button key={id} onClick={() => setPage(id)}
            style={{ display:"flex", alignItems:"center", gap:8, padding:"8px 10px", borderRadius:8, border:"none", background: page===id?"#f0fdf4":"none", color: page===id?"#15803d":"#4b5563", fontSize:12, fontWeight: page===id?600:400, cursor:"pointer", marginBottom:2, textAlign:"left", width:"100%" }}>
            <span>{icon}</span>{label}
          </button>
        ))}
        <div style={{ marginTop:"auto" }}>
          <button onClick={() => { setClient(null); setPage("dashboard"); }}
            style={{ width:"100%", fontSize:11, color:"#6b7280", background:"#f9fafb", border:"1px solid #e5e7eb", borderRadius:8, padding:"7px 10px", cursor:"pointer", textAlign:"left" }}>
            ⚙️ Modifier la config
          </button>
        </div>
      </div>

      <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
        <div style={{ padding:"0.75rem 1.5rem", background:"#fff", borderBottom:"1px solid #e5e7eb", display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:14, fontWeight:600, color:"#111827" }}>{NAV.find(n => n.id===page)?.label}</span>
          <span style={{ fontSize:11, color:"#9ca3af", marginLeft:6 }}>{client.name} · {client.location}</span>
        </div>
        <div style={{ flex:1, padding:"1.5rem", overflowY:"auto" }}>
          {page==="dashboard" && <DashboardTab months={months} client={client} />}
          {page==="content"   && <ContentTab client={client} />}
          {page==="calendar"  && <CalendarTab />}
          {page==="tracking"  && <TrackingTab months={months} setMonths={setMonths} />}
          {page==="audit"     && <AuditTab client={client} />}
        </div>
      </div>
    </div>
  );
}
